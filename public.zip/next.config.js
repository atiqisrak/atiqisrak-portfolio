/** @type {import('next').NextConfig} */
const nextConfig = {
  // next export
  output: "export",
};

module.exports = nextConfig;
